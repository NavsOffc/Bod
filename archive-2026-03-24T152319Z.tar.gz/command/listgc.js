const fs = require("fs");
const path = require("path");

const blacklistPath = path.join(process.cwd(), "ADDTIONAL", "whitelist.json");

function getBlacklist() {
    try {
        if (!fs.existsSync(blacklistPath)) {
            const dirPath = path.dirname(blacklistPath);
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
            }
            fs.writeFileSync(blacklistPath, "[]");
            return [];
        }
        return JSON.parse(fs.readFileSync(blacklistPath));
    } catch (error) {
        console.error("Gagal membaca blacklist:", error);
        return [];
    }
}

const listgc = async (m, { client }) => {
    try {
        const sender = m.chat;

        await client.sendMessage(sender, {
            text: "📡 *Mengambil daftar grup...*\n\nMohon tunggu sebentar."
        });

        const groups = await client.groupFetchAllParticipating();
        const groupList = Object.values(groups);
        
        if (groupList.length === 0) {
            return client.sendMessage(sender, {
                text: "❌ Bot tidak terdaftar di grup manapun."
            });
        }

        const blacklist = getBlacklist();
        
        let msg = `📋 *DAFTAR GRUP YANG BOT IKUTI*\n\n`;
        msg += `Total: ${groupList.length} grup\n`;
        msg += `🚫 Blacklist: ${groupList.filter(g => blacklist.includes(g.id)).length} grup\n`;
        msg += `✅ Aktif: ${groupList.filter(g => !blacklist.includes(g.id)).length} grup\n\n`;
        msg += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        groupList.forEach((group, index) => {
            const isBlacklisted = blacklist.includes(group.id);
            const statusIcon = isBlacklisted ? "🚫" : "✅";
            const memberCount = group.participants?.length || 0;
            
            msg += `${index + 1}. ${statusIcon} *${group.subject}*\n`;
            msg += `   🆔 ID: ${group.id}\n`;
            msg += `   👥 Member: ${memberCount} orang\n`;
            msg += `   📌 Status JPM: ${isBlacklisted ? "DI-BLACKLIST" : "AKTIF"}\n\n`;
        });
        
        msg += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        msg += `📌 *Cara Menambahkan ke Blacklist:*\n`;
        msg += `• Via ID: .addblgc <ID Grup>\n`;
        msg += `• Via grup: ketik .addbl di dalam grup\n\n`;
        msg += `📌 *Cara Menghapus dari Blacklist:*\n`;
        msg += `• Via ID: .delblgc <ID Grup>\n`;
        msg += `• Via grup: ketik .delbl di dalam grup`;

        await client.sendMessage(sender, { text: msg });
        
    } catch (error) {
        console.error('Error:', error);
        const sender = m?.chat;
        if (sender && client) {
            await client.sendMessage(sender, { 
                text: '❌ Gagal mengambil daftar grup. Coba lagi nanti.' 
            });
        }
    }
};

module.exports = listgc;
module.exports.command = ['listgc', 'daftargrup', 'groups'];
module.exports.tags = ['admin'];