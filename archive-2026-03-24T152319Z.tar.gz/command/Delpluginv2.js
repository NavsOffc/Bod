const fs = require("fs");
const path = require("path");

const handler = async (m, { reply, text, command }) => {
try {
    // Baca owner dari owner.json
    const ownerPath = '/home/container/database/owner.json';
    let ownerData = [];
    
    try {
        if (fs.existsSync(ownerPath)) {
            const rawData = fs.readFileSync(ownerPath, 'utf-8');
            ownerData = JSON.parse(rawData);
        } else {
            return reply('File owner.json tidak ditemukan!');
        }
    } catch (error) {
        console.log('Error reading owner.json:', error);
        return reply('Error membaca file owner.json');
    }

    // Cek owner
    const isOwner = Array.isArray(ownerData) 
        ? ownerData.includes(m.sender)
        : ownerData === m.sender;

    if (!isOwner) return reply(mess.owner || 'Hanya owner yang bisa menggunakan command ini!')

    // Baca direktori command (bukan Plugins)
    const commandDir = "./command";
    if (!fs.existsSync(commandDir)) {
        return reply("Folder command tidak ditemukan!");
    }

    const commands = await fs.readdirSync(commandDir);
    if (commands.length < 1) return reply("Tidak ada file command");
    
    if (!text || !text.endsWith(".js")) return reply(`*contoh:* ${command} ping.js`);
    
    // Cek file dengan case insensitive
    const commandFile = commands.find(file => file.toLowerCase() === text.toLowerCase());
    if (!commandFile) {
        return reply(`Command "${text}" tidak ditemukan. Daftar command: ${commands.join(", ")}`);
    }
    
    // Hapus file dari folder command
    await fs.unlinkSync(path.join(commandDir, commandFile));
    return reply(`Berhasil menghapus command *${commandFile}*`);
    
} catch (err) {
    console.log(err);
    return reply('Terjadi error: ' + err.message);
}
}

handler.command = ["delp", "dp", "delplugin", "delplugins"];
module.exports = handler;