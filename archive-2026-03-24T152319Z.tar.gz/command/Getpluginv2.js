const fs = require("fs")
const path = require("path")

let handler = async (m, { reply, text }) => {
try {
    // Baca owner dari owner.json
    const ownerPath = '/home/container/database/owner.json';
    let ownerData = [];
    
    try {
        if (fs.existsSync(ownerPath)) {
            const rawData = fs.readFileSync(ownerPath, 'utf-8');
            ownerData = JSON.parse(rawData);
        } else {
            return reply('File owner.json tidak ditemukan!');
        }
    } catch (error) {
        console.log('Error reading owner.json:', error);
        return reply('Error membaca file owner.json');
    }

    // Cek owner
    const isOwner = Array.isArray(ownerData) 
        ? ownerData.includes(m.sender)
        : ownerData === m.sender;

    if (!isOwner) return reply(global.mess.owner || 'Hanya owner yang bisa menggunakan command ini!')
    
    if (!text) return m.reply("namafile plugins nya")
    if (!text.endsWith(".js")) return m.reply("Nama file harus berformat .js")
    if (!fs.existsSync("./command/" + text.toLowerCase())) return m.reply("File plugins tidak ditemukan!")
    
    let res = await fs.readFileSync("./command/" + text.toLowerCase())
    return m.reply(`${res.toString()}`)
} catch (err) {
    console.log(err)
    return m.reply('Terjadi error: ' + err.message)
}
}

handler.command = ["getp", "gp", "getplugins", "getplugin"]
module.exports = handler