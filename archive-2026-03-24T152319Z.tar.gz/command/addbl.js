const fs = require("fs");
const path = require("path");

const filePath = path.join(process.cwd(), "ADDTIONAL", "whitelist.json");

function getData() {
    if (!fs.existsSync(filePath)) {
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        fs.writeFileSync(filePath, "[]");
    }
    return JSON.parse(fs.readFileSync(filePath));
}

function saveData(data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

const addbl = async (m, { client, message }) => {
    const from = m.chat;

    if (!from || !from.endsWith("@g.us")) {
        return client.sendMessage(from, {
            text: "❌ Perintah ini hanya bisa digunakan di dalam group."
        });
    }

    let data = getData();

    if (data.includes(from)) {
        return client.sendMessage(from, {
            text: "⚠️ Group ini sudah ada di blacklist JPM."
        });
    }

    data.push(from);
    saveData(data);

    await client.sendMessage(from, {
        text: "🚫 GC udh di blacklist😹"
    });
};

module.exports = addbl;
module.exports.command = ['xaddbl', 'addblacklist'];
module.exports.tags = ['admin'];