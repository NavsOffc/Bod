const fetch = require('node-fetch');

let handler = async (m, { client, text }) => {
  if (!text) return m.reply('Mana Username Instagram nya?')

  try {
    let res = await fetch(`https://api.siputzx.my.id/api/stalk/instagram?username=${encodeURIComponent(text)}`)
    let data = await res.json()
    if (!data.status) return m.reply('User Instagram tidak ditemukan!')

    let user = data.data
    let avatar = user.profile_pic_url

    let teks = `
*Info Instagram ${user.username}*
📛 Nama Lengkap : ${user.full_name}
✍️ Bio : ${user.biography || 'Tidak ada'}
🔗 Link Eksternal : ${user.external_url || 'Tidak ada'}
👥 Followers : ${user.followers_count}
🔗 Following : ${user.following_count}
📝 Jumlah Post : ${user.posts_count}
🔒 Private : ${user.is_private ? 'Ya' : 'Tidak'}
🏢 Akun Bisnis : ${user.is_business_account ? 'Ya' : 'Tidak'}
✅ Verified : ${user.is_verified ? 'Ya' : 'Tidak'}
    `.trim()

    client.sendMessage(m.chat, { image: { url: avatar }, caption: teks }, { quoted: m })

  } catch (e) {
    console.log(e)
    m.reply('Terjadi kesalahan saat mengambil data.')
  }
}

// Bisa dipanggil dengan beberapa keyword
handler.command = ['instagramstalk', 'igstalk']
handler.tags = ['stalk']

module.exports = handler
